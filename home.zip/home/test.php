<?php
echo 'User IP Address : '. $_SERVER['REMOTE_ADDR'];

?>